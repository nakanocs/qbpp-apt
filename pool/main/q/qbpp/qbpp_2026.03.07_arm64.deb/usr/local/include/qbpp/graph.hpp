/// @file qbpp_graph.hpp
/// @brief Graph drawing utility for QBPP.
/// @details
/// This header defines classes for drawing graphs with Graphviz.
/// It is primarily used to visualize solutions to graph problems solved by
/// QBPP.
///
/// Graphviz must be installed to use this utility.
/// This utility is designed to generate layouts using Graphviz's "neato"
/// command.
///
/// This header is intended for QUBO++ sample programs and demonstrations.
/// The API is subject to change without notice.
/// @author Koji Nakano
/// @version 2026.01.18

#pragma once
#include <algorithm>
#include <array>
#include <boost/polygon/voronoi.hpp>
#include <cctype>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <optional>
#include <sstream>
#include <string>
#include <utility>
#include <vector>
namespace qbpp::graph {
inline constexpr std::array<const char*, 10> NodeColor = {
    "#FFFFFF",  
    "#FFFF66",  
    "#66FFFF",  
    "#66FF66",  
    "#FF6666",  
    "#FF66FF",  
    "#FFCC66",  
    "#99FFCC",  
    "#CC99FF",  
    "#66CCFF"   
};
inline constexpr std::array<const char*, 10> EdgeColor = {
    "#000000",  
    "#CC0000",  
    "#00AA00",  
    "#0066CC",  
    "#CC8800",  
    "#00AAAA",  
    "#AA00AA",  
    "#888800",  
    "#6600CC",  
    "#003366"   
};
inline std::string escape_dot_string(const std::string& s) {
  std::string out;
  out.reserve(s.size());
  for (char ch : s) {
    if (ch == '\\' || ch == '"') out.push_back('\\');
    out.push_back(ch);
  }
  return out;
}
class Node {
  std::string label_;
  std::string xlabel_;
  std::string color_ = "#FFFFFF";
  std::optional<float> penwidth_;
  std::optional<std::pair<float, float>> position_;
 public:
  explicit Node(const std::string& label) : label_(label) {}
  template <class I, std::enable_if_t<std::is_integral_v<I>, int> = 0>
  explicit Node(I label)
      : label_(std::to_string(static_cast<long long>(label))) {}
  Node& color(std::string color_hex) {
    color_ = std::move(color_hex);
    return *this;
  }
  Node& color(int64_t index) {
    if (index >= 0 && index < static_cast<int64_t>(NodeColor.size()))
      color_ = NodeColor[static_cast<size_t>(index)];
    else
      color_ = "#888888";
    return *this;
  }
  Node& position(float x, float y) {
    position_ = std::make_pair(x, y);
    return *this;
  }
  Node& position(int x, int y) {
    return position(static_cast<float>(x), static_cast<float>(y));
  }
  Node& xlabel(const std::string& xlabel) {
    xlabel_ = xlabel;
    return *this;
  }
  Node& penwidth(float w) {
    penwidth_ = w;
    return *this;
  }
  std::string draw() const {
    std::ostringstream oss;
    oss << " \"" << escape_dot_string(label_) << "\" [";
    std::vector<std::string> attrs;
    if (!color_.empty()) {
      attrs.push_back("fillcolor=\"" + color_ + "\"");
    }
    if (penwidth_) {
      attrs.push_back("penwidth=" + std::to_string(*penwidth_));
    }
    if (position_) {
      attrs.push_back("pos=\"" + std::to_string(position_->first) + "," +
                      std::to_string(position_->second) + "!\"");
    }
    if (xlabel_ != "") {
      attrs.push_back("xlabel=\"" + escape_dot_string(xlabel_) + "\"");
    }
    for (size_t i = 0; i < attrs.size(); ++i) {
      if (i > 0) oss << ", ";
      oss << attrs[i];
    }
    oss << "];\n";
    return oss.str();
  }
  const std::optional<std::pair<float, float>> position() const {
    return position_;
  }
};
class Edge {
  std::string from_;
  std::string to_;
  bool directed_ = false;
  std::string color_ = "#000000";
  std::optional<float> penwidth_ = {};
  std::string style_ = "";
  std::string label_ = "";
 public:
  explicit Edge(const std::string& from, const std::string& to)
      : from_(from), to_(to) {}
  template <class I, std::enable_if_t<std::is_integral_v<I>, int> = 0>
  explicit Edge(I from, I to)
      : from_(std::to_string(static_cast<long long>(from))),
        to_(std::to_string(static_cast<long long>(to))) {}
  Edge& directed(bool is_directed = true) {
    directed_ = is_directed;
    return *this;
  }
  Edge& color(std::string color_hex) {
    color_ = std::move(color_hex);
    return *this;
  }
  template <class I, std::enable_if_t<std::is_integral_v<I>, int> = 0>
  Edge& color(I index) {
    if (index < static_cast<int64_t>(EdgeColor.size()) && index >= 0)
      color_ = EdgeColor[static_cast<size_t>(index)];
    else
      color_ = "#888888";
    return *this;
  }
  Edge& penwidth(float w) {
    penwidth_ = w;
    return *this;
  }
  Edge& style(const std::string& style) {
    style_ = style;
    return *this;
  }
  Edge& label(const std::string& label) {
    label_ = label;
    return *this;
  }
  std::string draw() const {
    std::ostringstream oss;
    oss << " \"" << from_ << "\" -> \"" << to_ << "\" [";
    std::vector<std::string> attrs;
    if (!directed_) {
      attrs.push_back("dir=none");
    }
    if (!color_.empty()) {
      attrs.push_back("color=\"" + color_ + "\"");
    }
    if (penwidth_) {
      attrs.push_back("penwidth=" + std::to_string(*penwidth_));
    }
    if (!style_.empty()) {
      attrs.push_back("style=\"" + style_ + "\"");
    }
    if (!label_.empty()) {
      attrs.push_back("label=\"" + escape_dot_string(label_) + "\"");
    }
    for (size_t i = 0; i < attrs.size(); ++i) {
      if (i > 0) oss << ", ";
      oss << attrs[i];
    }
    oss << "];\n";
    return oss.str();
  }
};
class GraphDrawer {
  std::vector<Node> nodes_;
  std::vector<Edge> edges_;
  bool has_positions_ = false;
 public:
  void add_node(const Node& node) {
    if (node.position()) {
      has_positions_ = true;
    }
    nodes_.emplace_back(node);
  }
  void add(const Node& node) { add_node(node); }
  void add_edge(const Edge& edge) { edges_.emplace_back(edge); }
  void add(const Edge& edge) { add_edge(edge); }
  std::string draw() const {
    std::ostringstream oss;
    oss << "digraph G {\n";
    oss << "  node [shape=circle, fixedsize=true, style=filled, "
           "fontcolor=black, color=black];\n";
    for (const auto& node : nodes_) {
      oss << node.draw();
    }
    for (const auto& edge : edges_) {
      oss << edge.draw();
    }
    oss << "}\n";
    return oss.str();
  }
 private:
  static std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return (char)std::tolower(c); });
    return s;
  }
  static std::string output_format_from_filename(const std::string& filename) {
    namespace fs = std::filesystem;
    std::string ext = fs::path(filename).extension().string();
    if (!ext.empty() && ext[0] == '.') ext.erase(0, 1);
    ext = to_lower(ext);
    if (ext.empty()) return "png";
    if (ext == "jpeg") return "jpg";
    return ext;
  }
  static std::string sanitize_filename(const std::string& filename) {
    std::string safe = filename;
    safe.erase(std::remove_if(safe.begin(), safe.end(),
                              [](char c) {
                                return c == ';' || c == '&' || c == '|' ||
                                       c == '`';
                              }),
               safe.end());
    return safe;
  }
 public:
  bool write(const std::string& filename) const {
    const std::string fmt = output_format_from_filename(filename);
    std::string cmd = "neato";
    if (has_positions_) cmd += " -n2";
    cmd += " -T" + fmt;
    cmd += " -o \"" + sanitize_filename(filename) + "\"";
    std::unique_ptr<FILE, decltype(&pclose)> fp(popen(cmd.c_str(), "w"),
                                                pclose);
    if (!fp) return false;
    const std::string dot = draw();
    const size_t n = std::fwrite(dot.data(), 1, dot.size(), fp.get());
    if (n != dot.size()) return false;
    FILE* raw_fp = fp.release();
    const int rc = pclose(raw_fp);
    return (rc == 0);
  }
};
}  
