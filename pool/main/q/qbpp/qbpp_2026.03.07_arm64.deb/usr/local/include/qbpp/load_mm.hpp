#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>
#include "qbpp.hpp"
std::pair<qbpp::Vector<qbpp::Var>, qbpp::Expr> load_mm(
    const std::string& filename) {
  std::ifstream file(filename);
  if (!file) {
    throw std::runtime_error("Could not open file: " + filename);
  }
  std::string line;
  if (!std::getline(file, line)) {
    throw std::runtime_error("Could not read the first line of file: " +
                             filename);
  }
  std::istringstream head(line);
  qbpp::vindex_t var_count;
  std::size_t term_count;
  std::size_t temp;  
  if (!(head >> var_count >> term_count >> temp)) {
    throw std::runtime_error("The first line does not contain three integers.");
  }
  auto x = qbpp::var("x", var_count);
  qbpp::Expr expr = qbpp::coeff_t{0};
  for (std::size_t i = 0; i < term_count; ++i) {
    if (!std::getline(file, line)) {
      throw std::runtime_error("Unexpected EOF at term " + std::to_string(i) +
                               " of " + std::to_string(term_count));
    }
    const auto p = line.find_first_not_of(" \t\r\n");
    if (p == std::string::npos || line[p] == '#') {
      --i;
      continue;
    }
    std::istringstream iss(line);
    qbpp::coeff_t coeff;
    if (!(iss >> coeff)) {
      throw std::runtime_error("Failed to read coefficient at term " +
                               std::to_string(i));
    }
    qbpp::Expr term = coeff;
    qbpp::vindex_t var;
    bool has_any_var = false;
    while (iss >> var) {
      if (var >= var_count) {
        throw std::runtime_error(
            "Variable index out of range at term " + std::to_string(i) +
            ": var=" + std::to_string(var) +
            " (var_count=" + std::to_string(var_count) + ")");
      }
      term *= x[var];
    }
    expr += term;
  }
  return {x, expr.simplify_as_binary()};
}
