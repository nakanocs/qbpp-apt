/// @file qbpp_exhaustive_solver.hpp
/// @author Koji Nakano
/// @brief Exhaustive HUBO Solver for solving HUBO problems.
/// @details The ExhaustiveSolver class provides a straightforward HUBO solver
/// that evaluates all possible solutions. This solver is primarily intended
/// for testing the correctness of HUBO expressions.
/// For more details on the algorithm, please refer to the following paper:
/// Masaki Tao et al., "A Work-Time Optimal Parallel Exhaustive Search
/// Algorithm for the QUBO and the Ising Model, with GPU Implementation," IPDPS
/// Workshops 2020: 557-566. https://doi.org/10.1109/IPDPSW50202.2020.00098
/// @version 2026.02.28

#pragma once
#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>
#include <atomic>
#include "qbpp.hpp"
namespace qbpp {
namespace exhaustive_solver {
#if defined(__SIZEOF_INT128__)
using qbpp::operator<<;
#endif
class SolDelta;
class Sol;
class SearchAlgorithm;
class ExhaustiveSolver;
class Sol : public qbpp::Sol {
  bool is_all_solutions_ = false;
  bool is_optimal_solutions_ = false;
  std::vector<qbpp::Sol> all_solutions_;
 public:
  explicit Sol(const HuboModel& hubo_model) : qbpp::Sol(hubo_model) {};
  Sol(const Sol&) = default;
  Sol(Sol&&) = default;
  Sol& operator=(const Sol&) = default;
  Sol& operator=(Sol&&) = default;
  std::vector<qbpp::Sol>& all_solutions() { return all_solutions_; }
  void all_solution_mode() {
    is_optimal_solutions_ = false;
    is_all_solutions_ = true;
  }
  void optimal_solution_mode() {
    is_optimal_solutions_ = true;
    is_all_solutions_ = false;
  }
  void all_solutions(std::vector<qbpp::Sol>&& all_solutions) {
    all_solutions_ = std::move(all_solutions);
    qbpp::Sol::operator=(all_solutions_.front());
  }
  std::string str() const {
    if (is_all_solutions_ || is_optimal_solutions_) {
      std::ostringstream oss;
      uint32_t count = 0;
      for (const auto& sol : all_solutions_) {
        oss << "(" << count++ << ") " << sol;
        if (count < all_solutions_.size()) oss << std::endl;
      }
      return oss.str();
    }
    return qbpp::str(static_cast<const qbpp::Sol&>(*this));
  }
  std::vector<qbpp::Sol>::const_iterator begin() const {
    return all_solutions_.begin();
  }
  std::vector<qbpp::Sol>::const_iterator end() const {
    return all_solutions_.end();
  }
  size_t size() const { return all_solutions_.size(); }
  const qbpp::Sol& operator[](size_t i) const { return all_solutions_[i]; }
  qbpp::Sol& operator[](size_t i) { return all_solutions_[i]; }
};
inline std::ostream& operator<<(std::ostream& os, const Sol& sol) {
  os << sol.str();
  return os;
}
class ExhaustiveSolver {
 protected:
  const HuboModel hubo_model_;
  bool enable_default_callback_ = false;
  bool verbose_ = false;
  std::optional<energy_t> target_energy_;
 public:
  ExhaustiveSolver(const HuboModel& hubo_model) : hubo_model_(hubo_model) {
    if (hubo_model_.var_count() >= 50) {
      throw std::invalid_argument(
          "ExhaustiveSolver: The number of variables exceeds the limit (50).");
    }
  }
  mutable std::mutex callback_mutex_;
  mutable std::optional<energy_t> prev_callback_energy_ = std::nullopt;
  virtual ~ExhaustiveSolver() = default;
  virtual void callback(const SolHolder& sol_holder) const {
    std::lock_guard<std::mutex> lock(callback_mutex_);
    if (enable_default_callback_) {
      if (!prev_callback_energy_.has_value() ||
          sol_holder.energy() < prev_callback_energy_.value()) {
        prev_callback_energy_ = sol_holder.energy();
        std::cout << "TTS = " << std::fixed << std::setprecision(3)
                  << std::setfill('0') << sol_holder.tts()
                  << "s Energy = " << sol_holder.energy() << std::endl;
      }
    }
  }
  vindex_t var_count() const { return hubo_model_.var_count(); }
  qbpp::Sol search();
  Sol search_optimal_solutions();
  Sol search_all_solutions();
  void enable_default_callback(bool enable = true) {
    enable_default_callback_ = enable;
  }
  void verbose(bool enable = true) { verbose_ = enable; }
  bool is_verbose() const { return verbose_; }
  void target_energy(energy_t energy) { target_energy_ = energy; }
  std::optional<energy_t> target_energy() const { return target_energy_; }
  const HuboModel& hubo_model() const { return hubo_model_; }
};
class SearchAlgorithm {
  const ExhaustiveSolver& exhaustive_solver_;
  const HuboModel& hubo_model_;
  const std::vector<vindex_t> var_order_;
  qbpp::SolHolder sol_holder_;
  bool is_all_solutions_ = false;
  bool is_optimal_solutions_ = false;
  std::vector<qbpp::Sol> all_solutions_;
  mutable std::mutex all_solutions_mutex_;
  std::vector<SolDelta> sol_deltas;
  mutable std::atomic<uint64_t> total_flip_count_{0};
  double prev_percent_ = 0.0;
  std::mutex progress_mutex_;
  const std::optional<energy_t> target_energy_;
  mutable std::atomic<bool> target_reached_{false};
  std::vector<vindex_t> init_var_order(const HuboModel& hubo_model) {
    std::vector<std::pair<size_t, vindex_t>> cost_var;
    cost_var.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      size_t cost = hubo_model.term2(i).size() +
                    hubo_model.term3(i).size() * 2 +
                    hubo_model.term4(i).size() * 3;
      for (const auto& dtv : hubo_model.dyn_terms(i))
        cost += dtv.size() * dtv.degree_minus_one();
      cost_var[i] = std::make_pair(cost, i);
    }
    std::sort(cost_var.begin(), cost_var.end());
    std::vector<vindex_t> var_order;
    var_order.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      var_order[i] = cost_var[i].second;
    }
    return var_order;
  }
 public:
  explicit SearchAlgorithm(const ExhaustiveSolver& exhaustive_solver)
      : exhaustive_solver_(exhaustive_solver),
        hubo_model_(exhaustive_solver_.hubo_model()),
        var_order_(init_var_order(hubo_model_)),
        sol_holder_(hubo_model_),
        target_energy_(exhaustive_solver.target_energy()) {}
  const HuboModel& hubo_model() const { return hubo_model_; }
  const std::vector<vindex_t>& var_order() const { return var_order_; }
  vindex_t var_count() const { return hubo_model_.var_count(); }
  std::vector<qbpp::Sol>& all_solutions() { return all_solutions_; }
  qbpp::SolHolder& sol_holder() { return sol_holder_; }
  bool reach_target_energy() const {
    if (is_all_solutions_ || is_optimal_solutions_) return false;
    if (target_reached_.load(std::memory_order_relaxed)) return true;
    if (!target_energy_.has_value()) return false;
    if (sol_holder_.energy() <= target_energy_.value()) {
      target_reached_.store(true, std::memory_order_relaxed);
      return true;
    }
    return false;
  }
  void register_new_sol(const qbpp::Sol& sol) {
    if (!is_all_solutions_ && sol_holder_.energy() < sol.energy()) return;
    std::lock_guard<std::mutex> lock(all_solutions_mutex_);
    if (is_all_solutions_) {
      all_solutions_.push_back(sol);
    } else if (is_optimal_solutions_) {
      if (sol_holder_.energy() == sol.energy()) {
        all_solutions_.push_back(sol);
      } else if (sol_holder_.energy() > sol.energy()) {
        all_solutions_.clear();
        all_solutions_.push_back(sol);
      }
    }
    if (sol_holder_.set_if_better(sol)) {
      exhaustive_solver_.callback(sol_holder_);
    }
  }
  void search();
  void search_optimal_solutions();
  void search_all_solutions();
  void gen_sol_deltas(SolDelta& sol_delta, vindex_t index);
  void add_flip_count(uint64_t count) {
    total_flip_count_ += count;
    if (exhaustive_solver_.is_verbose()) {
      std::lock_guard<std::mutex> lock(progress_mutex_);
      double percent = 100.0 * static_cast<double>(total_flip_count_) /
                       static_cast<double>(1ULL << var_count());
      if (percent - prev_percent_ >= 0.1) {
        prev_percent_ = percent;
        std::cout << "Progress: " << std::fixed << std::setprecision(1)
                  << percent << "%\r" << std::flush;
      }
    }
  }
};
class SolDelta : public Sol {
 protected:
  const HuboModel& hubo_model_;
  SearchAlgorithm& search_algorithm_;
  const std::vector<vindex_t>& var_order_ = search_algorithm_.var_order();
  std::vector<energy_t> delta_;
  std::vector<energy_t> delta_delta_;
  std::vector<vindex_t> dirty_indices_;
  uint64_t flip_count_ = 0;
 public:
  explicit SolDelta(SearchAlgorithm& search_algorithm)
      : Sol(search_algorithm.hubo_model()),
        hubo_model_(search_algorithm.hubo_model()),
        search_algorithm_(search_algorithm),
        delta_(var_count()),
        delta_delta_(var_count(), 0) {
    for (vindex_t i = 0; i < var_count(); ++i) {
      delta_[i] = hubo_model_.term1(i);
      const auto& t2 = hubo_model_.term2(i);
      for (size_t j = 0; j < t2.size(); ++j) {
        if (t2.indices(j)[0] & qbpp::vindex_neg_bit)
          delta_[i] += t2.coeff(j);
      }
      const auto& t3 = hubo_model_.term3(i);
      for (size_t j = 0; j < t3.size(); ++j) {
        const auto& inds = t3.indices(j);
        if ((inds[0] & qbpp::vindex_neg_bit) && (inds[1] & qbpp::vindex_neg_bit))
          delta_[i] += t3.coeff(j);
      }
      const auto& t4 = hubo_model_.term4(i);
      for (size_t j = 0; j < t4.size(); ++j) {
        const auto& inds = t4.indices(j);
        if ((inds[0] & qbpp::vindex_neg_bit) &&
            (inds[1] & qbpp::vindex_neg_bit) &&
            (inds[2] & qbpp::vindex_neg_bit))
          delta_[i] += t4.coeff(j);
      }
      for (const auto& dtv : hubo_model_.dyn_terms(i)) {
        const uint32_t nm1 = dtv.degree_minus_one();
        const vindex_t* dbase = dtv.indices_data();
        for (uint32_t j = 0; j < dtv.size(); ++j) {
          const vindex_t* idx = dbase + static_cast<size_t>(j) * nm1;
          bool all_neg = true;
          for (uint32_t k = 0; k < nm1; ++k) {
            if (!(idx[k] & qbpp::vindex_neg_bit)) { all_neg = false; break; }
          }
          if (all_neg) delta_[i] += dtv.coeffs_[j];
        }
      }
    }
  }
  template <size_t N>
  inline void update_delta_delta(const TermVector<N - 1>& terms,
                                 std::vector<energy_t>& delta_delta,
                                 energy_t flip_bit_sign) {
    static_assert(N >= 3, "N must be >= 3");
    for (size_t i = 0; i < terms.size(); ++i) {
      std::array<vindex_t, N - 1> idx{};
      std::array<uint8_t, N - 1> val{};
      uint8_t sum = 0;
      const auto& inds = terms.indices(i);
      for (size_t j = 0; j < N - 1; ++j) {
        idx[j] = inds[j] & qbpp::vindex_mask;
        uint8_t v = static_cast<uint8_t>(get(idx[j]));
        if (inds[j] & qbpp::vindex_neg_bit) v = static_cast<uint8_t>(1 - v);
        val[j] = v;
        sum = static_cast<uint8_t>(sum + val[j]);
      }
      const energy_t factor = terms.coeff(i) * flip_bit_sign;
      if (sum <= static_cast<uint8_t>(N - 3)) continue;
      if (sum == static_cast<uint8_t>(N - 1)) {
        for (size_t j = 0; j < N - 1; ++j) {
          if (delta_delta[idx[j]] == 0) dirty_indices_.push_back(idx[j]);
          delta_delta[idx[j]] -= factor;
        }
        continue;
      }
      for (uint8_t target = 0; target < N - 1; ++target) {
        if (val[target] == 0) {
          if (delta_delta[idx[target]] == 0)
            dirty_indices_.push_back(idx[target]);
          delta_delta[idx[target]] += factor;
          break;
        }
      }
    }
  }
  inline void update_delta_delta_dyn(const DynTermVector& terms,
                                     std::vector<energy_t>& delta_delta,
                                     energy_t flip_bit_sign) {
    const uint32_t nm1 = terms.degree_minus_one();
    const vindex_t* raw_base = terms.indices_data();
    const coeff_t* coeffs = terms.coeffs_data();
    for (size_t i = 0; i < terms.size(); ++i) {
      const vindex_t* raw_idx = raw_base + i * nm1;
      uint32_t sum = 0;
      for (uint32_t j = 0; j < nm1; ++j) {
        vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
        uint32_t v = static_cast<uint32_t>(get(base_j));
        if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
        sum += v;
      }
      if (sum + 2 <= nm1) continue;
      const energy_t factor = coeffs[i] * flip_bit_sign;
      if (sum == nm1) {
        for (uint32_t j = 0; j < nm1; ++j) {
          vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
          if (delta_delta[base_j] == 0) dirty_indices_.push_back(base_j);
          delta_delta[base_j] -= factor;
        }
        continue;
      }
      for (uint32_t j = 0; j < nm1; ++j) {
        vindex_t base_j = raw_idx[j] & qbpp::vindex_mask;
        uint32_t v = static_cast<uint32_t>(get(base_j));
        if (raw_idx[j] & qbpp::vindex_neg_bit) v = 1 - v;
        if (v == 0) {
          if (delta_delta[base_j] == 0) dirty_indices_.push_back(base_j);
          delta_delta[base_j] += factor;
          break;
        }
      }
    }
  }
  void inc_flip_count() {
    constexpr uint64_t iteration = 1000;
    if (++flip_count_ >= iteration) {
      search_algorithm_.add_flip_count(flip_count_);
      flip_count_ -= iteration;
    }
  }
  void clear_flip_count() {
    if (flip_count_ > 0) {
      search_algorithm_.add_flip_count(flip_count_);
      flip_count_ = 0;
    }
  }
  void flip(vindex_t flip_index) override {
    vindex_t index = var_order_[flip_index];
    energy_ = energy() + delta_[index];
    int32_t flip_bit_sign = 1 - 2 * get(index);
    dirty_indices_.clear();
    const auto& t2 = hubo_model_.term2(index);
    for (size_t i = 0; i < t2.size(); ++i) {
      vindex_t raw_j = t2.indices(i)[0];
      vindex_t j = raw_j & qbpp::vindex_mask;
      coeff_t coeff = t2.coeff(i);
      int32_t val_j = get(j);
      if (raw_j & qbpp::vindex_neg_bit) val_j = 1 - val_j;
      energy_t dd = coeff * flip_bit_sign * (1 - 2 * val_j);
      if (dd != 0 && delta_delta_[j] == 0) dirty_indices_.push_back(j);
      delta_delta_[j] += dd;
    }
    if (hubo_model_.max_power() <= 2) goto post_process;
    update_delta_delta<3>(hubo_model_.term3(index), delta_delta_, flip_bit_sign);
    if (hubo_model_.max_power() <= 3) goto dyn_process;
    update_delta_delta<4>(hubo_model_.term4(index), delta_delta_, flip_bit_sign);
  dyn_process:
    for (const auto& dtv : hubo_model_.dyn_terms(index))
      update_delta_delta_dyn(dtv, delta_delta_, flip_bit_sign);
  post_process:
    for (vindex_t i : dirty_indices_) {
      if (delta_delta_[i] == 0) continue;
      delta_[i] += delta_delta_[i];
      delta_delta_[i] = 0;
    }
    delta_[index] = -delta_[index];
    if (!energy_.has_value()) {
      throw std::out_of_range(THROW_MESSAGE("energy_ is not set."));
    }
    bit_vector_.flip(index);
    inc_flip_count();
  }
  void search(vindex_t index) {
    if (index >= 1) search(index - 1);
    if (search_algorithm_.reach_target_energy()) return;
    flip(index);
    search_algorithm_.register_new_sol(*this);
    if (index >= 1) search(index - 1);
  }
  void search() {
    search_algorithm_.register_new_sol(*this);
    search(var_count() - 1);
    clear_flip_count();
  }
};
inline qbpp::Sol ExhaustiveSolver::search() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search();
  return search_algorithm.sol_holder().sol();
}
inline Sol ExhaustiveSolver::search_optimal_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_optimal_solutions();
  Sol sol(hubo_model_);
  sol.optimal_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}
inline Sol ExhaustiveSolver::search_all_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_all_solutions();
  Sol sol(hubo_model_);
  sol.all_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}
inline void SearchAlgorithm::gen_sol_deltas(SolDelta& sol_delta,
                                            vindex_t index) {
  if (var_count() == index) return;
  gen_sol_deltas(sol_delta, index + 1);
  sol_delta.flip(index);
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, index + 1);
}
inline void SearchAlgorithm::search() {
  static constexpr int parallel_param = 8;
  SolDelta sol_delta(*this);
  if (hubo_model_.term_count() == 0) {
    register_new_sol(sol_delta);
    return;
  }
  if (var_count() <= 16) {
    register_new_sol(sol_delta);
    sol_delta.search(var_count() - 1);
    return;
  }
  sol_deltas.reserve(1 << parallel_param);
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, var_count() - parallel_param);
  tbb::parallel_for(
      tbb::blocked_range<size_t>(0, sol_deltas.size()),
      [&](const tbb::blocked_range<size_t>& range) {
        for (size_t i = range.begin(); i < range.end(); ++i) {
          if (reach_target_energy()) break;
          register_new_sol(sol_deltas[i]);
          sol_deltas[i].search(var_count() - (parallel_param + 1));
        }
      });
}
inline void SearchAlgorithm::search_optimal_solutions() {
  is_optimal_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}
inline void SearchAlgorithm::search_all_solutions() {
  is_all_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}
}  
}  
