/// @file qbpp_defs.hpp
/// @author Koji Nakano
/// @brief Header file for qbpp library definitions.
/// @version 2026.03.04
/// @details This file contains definitions and utility functions used in the
/// qbpp library.
#pragma once
#ifndef __CUDACC__
#include <boost/multiprecision/cpp_int.hpp>
#endif
#include <cstdint>
#include <cstdio>
#include <iomanip>
#include <limits>
#include <string>
#ifndef qbpp_message
#define qbpp_message(x) x
#endif
namespace qbpp {
using vindex_t = uint32_t;
constexpr vindex_t vindex_limit = std::numeric_limits<vindex_t>::max();
constexpr vindex_t vindex_neg_bit =
    vindex_t(1) << (std::numeric_limits<vindex_t>::digits - 1);
constexpr vindex_t vindex_mask = ~vindex_neg_bit;
constexpr size_t SEQ_THRESHOLD = 1000;
}  
extern "C" {
const char* qbpp_const_str(const char* param);
qbpp::vindex_t qbpp_new_var(const char* name);
const char* qbpp_var_str(qbpp::vindex_t index);
qbpp::vindex_t qbpp_var_set_size();
void qbpp_var_reset();
qbpp::vindex_t qbpp_increment_unnamed_var_count();
void* qbpp_bitvector_create(qbpp::vindex_t bit_count);
void* qbpp_bitvector_create_from_array(qbpp::vindex_t bit_count,
                                       const uint64_t* bit_array);
void* qbpp_bitvector_copy(const void* src);
void qbpp_bitvector_destroy(void* bv);
void qbpp_bitvector_set(void* bv, qbpp::vindex_t index, bool value);
bool qbpp_bitvector_get(const void* bv, qbpp::vindex_t index);
void qbpp_bitvector_flip(void* bv, qbpp::vindex_t index);
uint64_t qbpp_bitvector_get64(const void* bv, qbpp::vindex_t index64);
void qbpp_bitvector_set64(void* bv, qbpp::vindex_t index64, uint64_t value);
void qbpp_bitvector_clear(void* bv);
qbpp::vindex_t qbpp_bitvector_popcount(const void* bv);
qbpp::vindex_t qbpp_bitvector_size(const void* bv);
qbpp::vindex_t qbpp_bitvector_size64(const void* bv);
bool qbpp_bitvector_equal(const void* a, const void* b);
bool qbpp_bitvector_less_than(const void* a, const void* b);
const uint64_t* qbpp_bitvector_bits_ptr(const void* bv);
char* qbpp_bitvector_str(const void* bv);
void* qbpp_iv_mapper_create(qbpp::vindex_t var_count, const uint8_t* var_flags);
void qbpp_iv_mapper_destroy(void* mapper);
qbpp::vindex_t qbpp_iv_mapper_var_count(const void* mapper);
qbpp::vindex_t qbpp_iv_mapper_index(const void* mapper, qbpp::vindex_t var);
qbpp::vindex_t qbpp_iv_mapper_var(const void* mapper, qbpp::vindex_t index);
int qbpp_iv_mapper_has(const void* mapper, qbpp::vindex_t var);
uint64_t qbpp_hash(size_t size, const uint64_t* data);
void qbpp_queueset_capacity(uint32_t capacity);
size_t qbpp_queueset_size();
uint8_t qbpp_queueset_has(const void* bv);
uint8_t qbpp_queueset_insert(const void* bv);
uint32_t qbpp_random_gen32();
uint64_t qbpp_random_gen64();
double qbpp_random_gen_double();
void qbpp_random_set_seed(uint32_t seed);
void qbpp_license_key(const char* license_key);
const char* qbpp_license_info_str(bool activate, bool deactivate,
                                  uint32_t time_out, bool details);
size_t qbpp_max_var_count();
size_t qbpp_gpu_max_var_count();
}
namespace qbpp {
inline uint32_t random_gen32() { return qbpp_random_gen32(); }
inline uint64_t random_gen64() { return qbpp_random_gen64(); }
inline double random_gen_double() { return qbpp_random_gen_double(); }
inline void random_set_seed(uint32_t seed) { qbpp_random_set_seed(seed); }
template <typename T>
T random_gen(T n) {
  if constexpr (sizeof(T) <= 4 && std::is_integral_v<T>) {
    if (n <= 0) return 0;
    constexpr uint32_t R = std::numeric_limits<uint32_t>::max();
    uint32_t limit = (R / static_cast<uint32_t>(n)) * static_cast<uint32_t>(n);
    uint32_t r;
    do {
      r = random_gen32();
    } while (r >= limit);
    return static_cast<T>(r % static_cast<uint32_t>(n));
  }
  else if constexpr (sizeof(T) <= 8 && std::is_integral_v<T>) {
    if (n <= 0) return 0;
    constexpr uint64_t R = std::numeric_limits<uint64_t>::max();
    uint64_t limit = (R / static_cast<uint64_t>(n)) * static_cast<uint64_t>(n);
    uint64_t r;
    do {
      r = random_gen64();
    } while (r >= limit);
    return static_cast<T>(r % static_cast<uint64_t>(n));
  }
#ifdef __CUDACC__
  else if constexpr (sizeof(T) > 8) {
    static_assert(sizeof(T) == 0, "Unsupported type in random_gen");
  }
#else
  else if constexpr (boost::multiprecision::number_category<T>::value ==
                     boost::multiprecision::number_kind_integer) {
    if (n <= 0) return 0;
    size_t bitlen = boost::multiprecision::msb(n);
    T value;
    do {
      value = 0;
      size_t bits = 0;
      while (bits <= bitlen) {
        uint32_t r = random_gen32();
        for (int i = 0; i < 32 && bits <= bitlen; ++i, ++bits) {
          if (r & (1u << i)) value |= T(1) << bits;
        }
      }
    } while (value >= n);
    return value;
  } else {
    static_assert(sizeof(T) == 0, "Unsupported type in random_gen");
  }
#endif
}
enum class LicenseStatus : int32_t {
  Empty = 0,
  Error = 1,
  Unlicensed = 2,
  AnonymousTrial = 3,
  Licensed = 4
};
inline void license_key(const char* license_key = nullptr) {
  qbpp_license_key(license_key);
}
inline std::string license_info(bool activate_if_needed = false,
                                bool deactivate = false, uint32_t time_out = 20,
                                bool details = false,
                                const char* license_key = nullptr) {
  if (license_key != nullptr) qbpp_license_key(license_key);
  return qbpp_license_info_str(activate_if_needed, deactivate, time_out,
                               details);
}
}  
