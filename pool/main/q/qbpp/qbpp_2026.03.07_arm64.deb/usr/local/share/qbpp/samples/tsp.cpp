// Traveling Salesman Problem (TSP): Find the shortest tour visiting all cities.
// Uses a one-hot matrix x[i][j] = 1 if position i in the tour visits city j.
#include <qbpp/qbpp.hpp>
#include <qbpp/easy_solver.hpp>
class Cities {
  std::vector<std::pair<int, int>> coords{
      {10, 12}, {33, 125}, {12, 226}, {121, 11}, {108, 142},
      {111, 243}, {220, 4}, {210, 113}, {211, 233}};
 public:
  size_t size() const { return coords.size(); }
  const std::pair<int, int>& operator[](size_t i) const { return coords[i]; }
  int dist(size_t i, size_t j) const {
    auto [x1, y1] = coords[i];
    auto [x2, y2] = coords[j];
    int dx = x1 - x2, dy = y1 - y2;
    return static_cast<int>(
        std::llround(std::sqrt(static_cast<double>(dx * dx + dy * dy))));
  }
};
int main() {
  Cities cities;
  const size_t n = cities.size();
  auto x = qbpp::var("x", n, n);
  auto constraint = qbpp::sum(qbpp::vector_sum(x, 0) == 1) +
                    qbpp::sum(qbpp::vector_sum(x, 1) == 1);
  auto objective = qbpp::expr();
  for (size_t i = 0; i < n; ++i) {
    size_t next = (i + 1) % n;
    for (size_t j = 0; j < n; ++j)
      for (size_t k = 0; k < n; ++k)
        if (k != j) objective += cities.dist(j, k) * x[i][j] * x[next][k];
  }
  auto f = objective + 1000 * constraint;
  f.simplify_as_binary();
  auto solver = qbpp::easy_solver::EasySolver(f);
  solver.time_limit(1.0);
  auto sol = solver.search();
  auto tour = qbpp::onehot_to_int(sol(x));
  std::cout << "Tour:";
  int total_dist = 0;
  for (size_t i = 0; i < n; ++i) {
    auto [cx, cy] = cities[static_cast<size_t>(tour[i])];
    std::cout << " " << tour[i] << "(" << cx << "," << cy << ")";
    total_dist += cities.dist(static_cast<size_t>(tour[i]),
                              static_cast<size_t>(tour[(i + 1) % n]));
  }
  std::cout << std::endl;
  std::cout << "Total distance = " << total_dist << std::endl;
}
